package parking;

public class ParkingLot {
}
